import React, { useState, useEffect } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import {
  fetchCampaignNameDetails,
  fetchFields,
  createLeadForm,
  updateLeadForm,
} from "./LeadCreationService.js";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faEye,
  faEyeSlash,
  faArrowLeft,
  faTriangleExclamation,
} from "@fortawesome/free-solid-svg-icons";
import { useLocation, useNavigate } from "react-router-dom";
import { Modal, Button } from "react-bootstrap";
import "./LeadCreation.css";

const LeadCreation = () => {
  const [campaigns, setCampaigns] = useState([]);
  const [selectedCampaign, setSelectedCampaign] = useState("");
  const [fields, setFields] = useState([]); // Store dynamic fields
  const userid = sessionStorage.getItem("UserID");
  const [isModalOpen, setIsModalOpen] = useState(false); // Manage Modal
  const [message, setMessage] = useState("");
  const location = useLocation();
  const leadData = location.state?.leadData || null; // Get lead data if available
  const navigate = useNavigate();
  const [navigateToSummary, setNavigateToSummary] = useState(false);

  useEffect(() => {
    const loadCampaignNameData = async () => {
      try {
        const data = await fetchCampaignNameDetails(userid);
        setCampaigns(data?.data?.campaigns || []);
        console.log("campaign name Data:", data); 
      } catch (error) {
        console.error("Error fetching campaign data:", error);
      }
    };
    loadCampaignNameData();
  }, []);

  const fetchLeadFields = async (leadformid) => {
    try {
      const response = await fetch(
        `http://192.168.2.11:3003/leadFormManagement/getLeadFormJSON/${leadformid}`
      );
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      const data = await response.json();
      console.log("Lead Fields Data:", data); // Log fetched lead fields
      setFields(data?.data?.lead_form_JSON || []); // Store lead form fields
    } catch (error) {
      console.error("Error fetching lead fields:", error);
    }
  };

//   const handleCampaignChange = async (e) => {
//     const selectedValue = e.target.value;
//     console.log("Selected Campaign ID:", selectedValue);

//     // Update Formik state
//     formik.setFieldValue("campaignSelection", selectedValue);
//     formik.setTouched({ ...formik.touched, campaignSelection: true }, true);

//     // Update local state
//     setSelectedCampaign(selectedValue);

//     // Check if campaigns exist
//     if (!campaigns || campaigns.length === 0) {
//         console.error("Campaigns data is empty or undefined");
//         return;
//     }

//     // Find the corresponding leadFormId dynamically
//     const selectedCampaignData = campaigns.find(camp => camp.campaign_id === selectedValue);
//     console.log("Selected Campaign Data:", selectedCampaignData);

//     if (!selectedCampaignData) {
//         console.error("No campaign found for the selected ID:", selectedValue);
//         return;
//     }

//     const leadFormId = selectedCampaignData?.lead_form_id;
//     console.log("Lead Form ID:", leadFormId);

//     if (leadFormId) {
//         await fetchLeadFields(leadFormId);
//     } else {
//         setFields([]);
//     }
// };

const handleCampaignChange = async (e) => {
  const selectedValue = e.target.value;
  console.log("Selected Campaign ID:", selectedValue);

  // Find the selected campaign data
  const selectedCampaignData = campaigns.find(camp => camp.campaign_id === selectedValue);
  
  if (!selectedCampaignData) {
      console.error("No campaign found for the selected ID:", selectedValue);
      return;
  }

  console.log("Selected Campaign Data:", selectedCampaignData);

  // Extract leadFormId and campaign name
  const leadFormId = selectedCampaignData?.lead_form_id;
  const campaignName = selectedCampaignData?.campaign_name;

  console.log("Lead Form ID:", leadFormId);
  console.log("Campaign Name:", campaignName);

  // Update Formik values
  formik.setFieldValue("campaignSelection", selectedValue);
  formik.setFieldValue("select_campaign", campaignName); // Add this line
  formik.setTouched({ ...formik.touched, campaignSelection: true }, true);

  // Update local state
  setSelectedCampaign(selectedValue);

  // Fetch lead form fields if leadFormId exists
  if (leadFormId) {
      await fetchLeadFields(leadFormId);
  } else {
      setFields([]);
  }
};


useEffect(() => {
  if (leadData?.campaign_id) {
      setSelectedCampaign(leadData.campaign_id);
      console.log("Selected campaign ID from leadData:", leadData.campaign_id);

      // Find the corresponding leadFormId dynamically
      const selectedCampaignData = campaigns?.find(camp => camp.campaign_id === leadData.campaign_id);
      if (selectedCampaignData?.lead_form_id) {
          fetchLeadFields(selectedCampaignData.lead_form_id); // Fetch relevant form fields dynamically
      } else {
          console.error("No lead form found for campaign ID:", leadData.campaign_id);
          setFields([]); // Clear fields if no matching campaign
      }
  }
}, [leadData, campaigns]);

  // useEffect(() => {
  //   if (leadData) {
  //     setSelectedCampaign(leadData.campaign_id || "");
  //     console.log("selected campaignid:",leadData.campaign_id);
      
  //     if (leadData.campaign_id === "CM1740643245446BxGS0") {
  //       fetchLeadFields("LF1742185299469buWnz"); // Fetch relevant form fields
  //     }
  //   }
  // }, [leadData]);

  // Generate dynamic initial values for Formik
  const initialValues = fields.reduce(
    (acc, field) => {
      const fieldName = field.api_key || field.id; // Ensure correct mapping
      acc[fieldName] = leadData ? leadData[fieldName] || "" : ""; // Use leadData if available
      return acc;
    },
    {
      campaignSelection: leadData ? leadData.campaign_id || "" : "", // Pre-fill campaign
    }
  );

  const validationSchema = Yup.object().shape(
    fields.reduce(
      (acc, field) => {
        if (field.required === "yes") {
          acc[field.id] = Yup.string().required(`${field.text} is required`);
        }
        return acc;
      },
      {
        campaignSelection: Yup.string("Campaign selection is required"),
      }
    )
  );

  const formik = useFormik({
    initialValues,
    validationSchema,
    onSubmit: async (values) => {
      console.log("Lead Form Submitted:", values);
      console.log("Formik Values Before Submission:", formik.values);
      console.log("Fetched Lead Fields:", fields);

      // Map dynamic fields to proper payload keys
      const mappedValues = fields.reduce((acc, field) => {
        const key = field.api_key || field.id; // Ensure correct key
        acc[field.text.toLowerCase().replace(/\s/g, "_")] = values[key] || ""; // Convert label to key
        return acc;
      }, {});

      try {
        let response;
        let messageText = "";
        let selectedValue = values.campaignSelection;


        if (leadData) {
          // Editing an existing lead
          const editpayload = {
            lead_id: leadData.lead_id, // Ensure this exists in leadData
            modified_by: mappedValues?.modified_by || "000001",
            current_stage: mappedValues?.current_stage || "GA",
            stage_remarks:mappedValues?.stage_remarks || "Follow up",
            sub_stage: mappedValues?.sub_stage || "Not interested",
            title: mappedValues?.title || "",
            initials: mappedValues?.initials || "",
            first_name: mappedValues?.first_name || "",
            last_name: mappedValues?.last_name || "",
            mobile_number: mappedValues?.mobile_number || "",
            home_number: mappedValues?.home_number || "",
            email: mappedValues?.email || "",
            nic_number: mappedValues?.nic_number || "",
            address_line_1: mappedValues?.address_line_1 || "",
            address_line_2: mappedValues?.address_line_2 || "",
            address_line_3: mappedValues?.address_line_3 || "",
            date_of_birth: mappedValues?.date_of_birth || "",
            marital_status: mappedValues?.marital_status || "",
            monthly_income: mappedValues?.monthly_income || "",
            remarks: mappedValues?.remarks || "",
            allocation: mappedValues?.allocation || "",
            nearest_branch: mappedValues?.nearest_branch || "",
            term: mappedValues?.term || "",
            spouse_nic_number: mappedValues?.spouse_nic_number || "",
            district: mappedValues?.district || "",
            occupation: mappedValues?.occupation || "",
            type_product: mappedValues?.type_product || "",
            gender: mappedValues?.gender || "",
            educational_qualification:mappedValues?.educational_qualification || "",
          };

          console.log("Edit Payload:", editpayload);
          response = await updateLeadForm(editpayload);
          messageText = response.message || "Lead Updated Successfully";
        } else {
          // Creating a new lead
          const createpayload = {
            campaign_id: selectedValue,
            created_by:  mappedValues?.created_by || "000001",
            lead_channel: mappedValues?.lead_channel || "LMS",
            lead_source:mappedValues?.lead_source || "Broker",
            select_campaign: formik.values.select_campaign || "", 
            title: mappedValues?.title || "",
            initials: mappedValues?.initials || "",
            first_name: mappedValues?.first_name || "",
            last_name: mappedValues?.last_name || "",
            mobile_number: mappedValues?.mobile_number || "",
            home_number: mappedValues?.home_number || "",
            email: mappedValues?.email || "",
            nic_number: mappedValues?.nic_number || "",
            address_line_1: mappedValues?.address_line_1 || "",
            address_line_2: mappedValues?.address_line_2 || "",
            address_line_3: mappedValues?.address_line_3 || "",
            date_of_birth: mappedValues?.date_of_birth || "",
            marital_status: mappedValues?.marital_status || "",
            monthly_income: mappedValues?.monthly_income || "",
            remarks:
              mappedValues?.remarks ||
              "",
            allocation: mappedValues?.allocation || "",
            nearest_branch: mappedValues?.nearest_branch || "",
            term: mappedValues?.term || "",
            spouse_nic_number: mappedValues?.spouse_nic_number || "",
            district: mappedValues?.district || "",
            occupation: mappedValues?.occupation || "",
            type_product: mappedValues?.type_product || "",
            gender: mappedValues?.gender || "",
            educational_qualification:
              mappedValues?.educational_qualification || "",
          };

          console.log("Create Payload:", createpayload);
          response = await createLeadForm(createpayload);
          messageText = response.message || "Lead Created Successfully";
        }

        console.log("API Response:", response);
        setMessage(messageText);
        setIsModalOpen(true);
        setNavigateToSummary(true);
      } catch (error) {
        console.error("Error:", error);
        setMessage(
          error.message || "Failed to process request. Please try again."
        );
        setIsModalOpen(true);
      }
    },
  });

  const handleModalClose = () => {
    setIsModalOpen(false);
    if (
      message?.trim().toLowerCase() === "lead created successfully" ||
      message?.trim().toLowerCase() === "lead updated successfully"
    ) {
      navigate("/LeadSummary");
    }
  };

  // const handleBlurValidation = async (name, value) => {
  //   if (!name || !value) return; // Skip validation if name or value is missing

  //   // Validate mobile number format before making an API call
  //   if (name === 5 && !/^\d{12}$/.test(value)) {
  //     formik.setFieldError(name, "Mobile number must be 12 digits");
  //     return;
  //   }

  //   try {
  //     const response = await fetch(
  //       `http://192.168.2.11:3004/leadManagement/validateDuplicate?mobile_number=${encodeURIComponent(value)}`
  //     );

  //     if (!response.ok) {
  //       throw new Error(`HTTP error! Status: ${response.status}`);
  //     }

  //     const data = await response.json();

  //     if (data.exists) {
  //       formik.setFieldError(
  //         name,
  //         `${name === "nic_number" ? "NIC number" : "Mobile number"} already exists`
  //       );
  //     }
  //     setMessage(message || "No duplicate found.");
  //     setIsModalOpen(true);
  //   } catch (error) {
  //     console.error("Validation error:", error);
  //     setMessage(error.message || "Failed to process request. Please try again.");
  //     setIsModalOpen(true);
  //   }
  // };

  // const handleBlurValidation = async (name, value) => {
  //   if (!name || !value) return; // Skip validation if name or value is missing

  //   // Validate mobile number format before making an API call
  //   if (name === 5 && !/^\d{12}$/.test(value)) {
  //     formik.setFieldError(name, "Mobile number must be 12 digits");
  //     return;
  //   }

  //   try {
  //     const response = await fetch(
  //       `http://192.168.2.11:3004/leadManagement/validateDuplicate?mobile_number=${value}`
  //     );

  //     if (!response.ok) {
  //       throw new Error(`HTTP error! Status: ${response.status}`);
  //     }

  //     const data = await response.json();

  //     if (data.status === "failed" && data.duplicateFields?.includes("mobile_number")) {
  //       formik.setFieldError(name, data.message || "Duplicate record found");
  //       setMessage(data.message || "Duplicate record found");
  //       //setIsModalOpen(true);
  //     }
  //     else {
  //       formik.setFieldError(name, data.message || "No duplicate found.");
  //       // setMessage("No duplicate found.");
  //       // setIsModalOpen(true);
  //     }
  //   } catch (error) {
  //     console.error("Validation error:", error);
  //     setMessage(error.message || "Failed to process request. Please try again.");
  //     setIsModalOpen(true);
  //   }
  // };

  const handleBlurValidation = async (name, value) => {
    if (!name || !value) return; // Skip validation if name or value is missing

    // Define validation rules
    const validations = {
      mobile_no: {
        regex: /^\d{12}$/,
        error: "Mobile number must be 12 digits",
        apiKey: "mobile_number",
      },
      nic_number: {
        regex: /^[0-9]{9,12}$/,
        error: "NIC number must be 9 to 12 digits",
        apiKey: "nic_number",
      },
    };

    const fieldValidation = validations[name];

    if (fieldValidation && !fieldValidation.regex.test(value)) {
      formik.setFieldError(name, fieldValidation.error);
      return;
    }

    try {
      const response = await fetch(
        `http://192.168.2.11:3004/leadManagement/validateDuplicate?${fieldValidation.apiKey}=${value}`
      );

      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }

      const data = await response.json();

      if (
        data.status === "failed" &&
        data.duplicateFields?.includes(fieldValidation.apiKey)
      ) {
        formik.setFieldError(name, data.message || "Duplicate record found");
        setMessage(data.message || "Duplicate record found");
        // setIsModalOpen(true);
      } else {
        formik.setFieldError(name, "");
        setMessage("No duplicate found.");
        // setIsModalOpen(true);
      }
    } catch (error) {
      console.error("Validation error:", error);
      setMessage(
        error.message || "Failed to process request. Please try again."
      );
      setIsModalOpen(true);
    }
  };

  return (
    <div className="container">
      <form
        onSubmit={formik.handleSubmit}
        className="leadfieldsheight hidden-scroll"
      >
        {/* Campaign Selection Dropdown */}
        <div className="col-md-6 mb-3">
          <label className="form-label">
            Campaign Selection<span className="text-danger">*</span>
          </label>
          <select
            className="form-select"
            name="campaignSelection"
            value={formik.values.campaignSelection}
            onChange={handleCampaignChange}
            onBlur={formik.handleBlur}
            disabled={!!leadData}
          >
            <option value="">Select a Campaign</option>
            {campaigns.map((campaign) => (
              <option key={campaign.campaign_id} value={campaign.campaign_id}>
                {campaign.campaign_name}
              </option>
            ))}
          </select>
          {formik.touched.campaignSelection &&
            formik.errors.campaignSelection && (
              <div className="text-danger">
                {formik.errors.campaignSelection}
              </div>
            )}
        </div>

        {/* Dynamically Render Lead Fields */}
        {fields.length > 0 && (
          <div className="row mt-4">
            {fields.map((field) => (
              <div className="col-md-6 mb-3" key={field.id}>
                <label className="form-label">
                  {field.text}
                  {field.required === "yes" && (
                    <span className="text-danger">*</span>
                  )}
                </label>

                {/* Render input field based on datatype */}
                {field.datatype === "text" && (
                  <input
                    type="text"
                    className="form-control"
                    name={field.api_key || field.id} // Ensure this matches Formik's name value
                    value={formik.values[field.api_key || field.id] || ""}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                )}

                {/* {field.datatype === "number" && (
                  <input
                    type="number"
                    className="form-control"
                    name={field.api_key || field.id} // Ensure this matches Formik's name value
                    value={formik.values[field.api_key || field.id] || ""}
                    onChange={formik.handleChange}
                    onBlur={(e) => {
                      formik.handleBlur(e);
                      handleBlurValidation(e.target.name, e.target.value);
                    }}
                  />
                )} */}

                {field.datatype === "number" && (
                  <input
                    type="number"
                    className="form-control"
                    name={field.api_key || field.id} // Ensure this matches Formik's name value
                    value={formik.values[field.api_key || field.id] || ""}
                    onChange={formik.handleChange}
                    onBlur={(e) => {
                      formik.handleBlur(e);
                      // Call handleBlurValidation only for mobile_no and nic_number
                      if (["mobile_no", "nic_number"].includes(e.target.name)) {
                        handleBlurValidation(e.target.name, e.target.value);
                      }
                    }}
                  />
                )}


                {field.datatype === "email" && (
                  <input
                    type="email"
                    className="form-control"
                    name={field.api_key || field.id} // Ensure this matches Formik's name value
                    value={formik.values[field.api_key || field.id] || ""}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                )}

                {field.datatype === "date" && (
                  <input
                    type="date"
                    className="form-control"
                    name={field.api_key || field.id} // Ensure this matches Formik's name value
                    value={formik.values[field.api_key || field.id] || ""}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                )}

                {field.datatype === "select" && (
                  <select
                    className="form-select"
                    name={field.api_key || field.id} // Ensure this matches Formik's name value
                    value={formik.values[field.api_key || field.id] || ""}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  >
                    <option value="">Select an option</option>
                    {field.options.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                )}

                {field.datatype === "time" && (
                  <input
                    type="time"
                    className="form-control"
                    name={field.api_key || field.id} // Ensure this matches Formik's name value
                    value={formik.values[field.api_key || field.id] || ""}
                    onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                  />
                )}


                {/* Validation error messages */}
                {formik.touched[field.id] && formik.errors[field.id] && (
                  <div className="text-danger">{formik.errors[field.id]}</div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Submit Button */}
        <div className="fixed-bottom d-flex justify-content-end mb-4 me-3">
          <Button
            variant="secondary"
            className="red-outline-button me-5"
            style={{ width: "10%" }}
          >
            Cancel
          </Button>
          <Button
            variant="success"
            className="bottombuttons me-5"
            style={{ width: "10%" }}
            type="submit"
          >
            Create Lead
          </Button>
        </div>
      </form>

      <Modal show={isModalOpen} onHide={() => setIsModalOpen(false)} centered>
        <Modal.Body className="text-center p-4">
          {message?.trim().toLowerCase() === "lead created successfully" ||
          message?.trim().toLowerCase() === "lead updated successfully" ? (
            <img src="/greentick.gif" alt="Success" width="103" height="103" />
          ) : (
            <FontAwesomeIcon
              icon={faTriangleExclamation}
              size="3x"
              style={{ color: "#7a0014" }}
            />
          )}

          <h5
            className="text-lg font-semibold mt-3"
            style={{ color: "#671E75" }}
          >
            {message || "Something went wrong."}
          </h5>

          <button
            className="mt-4 px-4 py-2 rounded-lg text-white"
            onClick={handleModalClose}
            style={{
              backgroundColor: "#671E75",
              border: "none",
              color: "#FFFFFF",
            }}
          >
            OK
          </button>
        </Modal.Body>
      </Modal>
    </div>
  );
};

export default LeadCreation;
